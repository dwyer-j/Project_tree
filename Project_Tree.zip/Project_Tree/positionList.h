#include <iostream>
//#include "DLinkedList.h"
#include <vector>
#include "position.h"

template <typename T>
class PositionList
{
public:
   PositionList();

   ~PositionList();

   bool empty() const {return (children.size() = 0);}

   //Modify functions
   void removeFront();
   void removeBack();
   void addFront(const Position<T>& value);
   void addBack(const Position<T>& value);
   
   PositionList<T> children() const;
   bool isExternal() const;

   //Access functions
   int getSize() const { return children_.size(); }
   const T& front() const;
   const T& back() const;
   
   int size_;
 private:
   
   std::vector<Position*> children_;
};

//Default Constructor
template<typename T>
PositionList<T>::PositionList()
{
   //I could not get this line of code to work which inpeded my ability to make progress
   //How do I make a vector of positions?
   children_ = new std::vector(Position<T>);
    
}


//Adds to the front of the list
template<typename T>
void PositionList<T>::addFront(const Position<T>& value)
{
   children_.pushBack(value);

}


template<typename T>
PositionList<T> PositionList<T>::children() const
{
   return (*this);
}

template<typename T>
bool PositionList<T>::isExternal() const 
{
   return (children_.size() == 0);
}
