/*
Jeffrey Dwyer
Filename: DLinkedList.h
Description : This class acts as a doubly linked list
*/
#pragma once
#include "node.h"
#include <iostream>

template<typename T>
class DLinkedList 
{
public:
   //Constructors
   DLinkedList();
   DLinkedList(const DLinkedList<T>& listToCopy);

   //Destructor
   ~DLinkedList();
  
   bool empty() const {return (size_ > 0);}
   
   //Modify functions
   void removeFront();
   void removeBack();
   void addFront(const Position<T>& e);
   void addBack(const Position<T>& e); 

   void copy(const DLinkedList& other);
   
   //Access functions
   int getSize() const { return size_; }
   const T& front() const;
   const T& back() const;  
 
   //Print operator/function
   std::ostream& operator<< (std::ostream& os);
   void print(std::ostream& os) const;


   Node<T>* tail_;
   Node<T>* head_;

   int size_;

}; 

template<typename T>
std::ostream& DLinkedList<T>::operator<< (std::ostream& os)
{
   print(os);
   
   return os;
}
//Print function
template<typename T>
void DLinkedList<T>::print (std::ostream& os) const
{
   os << "[ ";
   
   Node<T>* currNode;
   currNode = head_->next;
   
   while(currNode != tail_)
   {
      os << (currNode->value);

      currNode = currNode->next;
   }

   os << " ]";
}
//Default Constructor
template<typename T>
DLinkedList<T>::DLinkedList()
{
   tail_ = new Node<T>();
   head_ = new Node<T>();

   head_->next = tail_;
   tail_->prev = head_;

   size_ = 0;
}
//Copy constructor
template<typename T>
DLinkedList<T>::DLinkedList(const DLinkedList<T>& listToCopy)
{
   tail_ = new Node<T>();
   head_ = new Node<T>();

   head_->next = tail_;
   tail_->prev = head_;

   copy(listToCopy);
}
//Destructor
template<typename T>
DLinkedList<T>::~DLinkedList()
{
   Node<T>* current = head_->next;
   Node<T>* nextNode;

   while(current != tail_)
   {
      nextNode = current->next;

      delete current;
      
      current = nextNode;
   }

   head_->next = tail_;
   tail_->prev = head_;
   
}
//Copy one linked list to another
template<typename T>
void DLinkedList<T>::copy(const DLinkedList<T>& listToCopy)
{
   Node<T>* currNode;
   currNode = listToCopy.head_->next;

   Node<T>* currNodeThis;
   currNodeThis = head_->next;

   //If listToCopy is smaller
   while(currNode != listToCopy.tail_ && currNodeThis != tail_)
   {
       currNodeThis->value = currNode->value;

       currNodeThis = currNodeThis->next;
       currNode = currNode->next;    
   }

   if(currNode != listToCopy.tail_)
   {
      while(currNode != listToCopy.tail_)
      {
         append(currNode->value);
         currNode = currNode->next;
      }
   }
   else
   {
       while(currNodeThis != tail_)
       {
          removeFront();
       }
   }
}
//Adds to the front of the list
template<typename T>
void DLinkedList<T>::addFront(const Position<T>& value)
{
  Node<T>* newNode = new Node<T>(value);

  newNode->prev = tail_->prev;
  newNode->next = tail_;
  tail_->prev = newNode;
  (newNode->prev)->next = newNode;

  size_++;
}
//Adds to the back of the list
template<typename T>
void DLinkedList<T>::addBack(const Position<T>& value)
{
  Node<T>* newNode = new Node<T>(value);

  newNode->next = head_->next;
  newNode->prev = head_;
  head_->next = newNode;
  (newNode->next)->prev = newNode;

  size_++;
}

//Removes the front of the list
template<typename T>
void DLinkedList<T>::removeFront()
{
    tail_->prev = (tail_->prev)->prev;
    (tail_->prev)->next = tail_;
    size_--;
}

//Removes the back of the list
template<typename T>
void DLinkedList<T>::removeBack()
{
    head_->next = (head_->next)->next;
    (head_->next)->prev = head_;
    --size_;
}

