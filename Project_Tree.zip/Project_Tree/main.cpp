#include <iostream>
#include "tree.h"


int main()
{
   Tree<char> myTree;
   
   Position<char> a('a');
   Position<char> b('b');
   Position<char> c('c');
   Position<char> d('d');
   Position<char> e('e');
   Position<char> f('f');
   Position<char> g('g');

   PositionList<char> rootChildren;
   rootChildren.addFront(a);
   rootChildren.addFront(b);
   rootChildren.addFront(c);

   PositionList<char> aChildren;
   aChildren.addFront(d);

   PositionList<char> cChildren;
   cChildren.addFront(e);
   cChildren.addFront(f);

   PositionList<char> fChildren;
   fChildren.addFront(g);
   

   return 0;
}
